
# ################################
# # It's really ugly but needed to be able to load pickle file with Pattern stored inside #
# ################################
# # from sys import path, modules
# # from os.path import dirname as dir
# # path.append(dir(path[0]))
# # from logsparser import Pattern
# # modules['Pattern'] = Pattern
# # from relationsdiscover import Model
# # modules['Model'] = Model
# ################################

# from logflow.logsparser import Pattern
# from logflow.relationsdiscover import Model
# from Dataset import Dataset
# from Workflow import Workflow

# dataset = Dataset(path_model="../../model/", name_model="DKRZ", path_data="../../data/DKRZ/2018_05_log/m11235_2018_05_log", index_line_max=23399)
# workflow = Workflow(dataset)
# workflow.get_tree(index_line=23384)




